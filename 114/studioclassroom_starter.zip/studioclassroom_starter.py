from google import genai
from google.genai import types
from dotenv import load_dotenv
import os
import re

# Load environment variables
load_dotenv()

# Set up the Gemini API key
username = os.environ.get("webap_username")
password = os.environ.get("webap_password")
ok=True
if not username:
    print('你未在你的 .env 設定帳號')
    ok=False
if not password:
    print('你未在你的 .env 設定密碼')
    ok=False
if ok:
    print(f'你的帳號是: {username}')
    print(f'你的密碼是: {password}')
